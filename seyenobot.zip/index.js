const Discord = require("discord.js");

const client = new Discord.Client();

var prefix = "=";

client.login("NTI3MTc2NDc4NTQzMzE0OTU2.DwP6-Q.7HmAcIzb_3b7CBgXp8gm0S8D4nU");